# SkillSwap Cloud ⇄

**Share What You Know. Learn What You Need.**

A cloud-based student skill exchange platform built as a CSE Cloud Computing mini/major project. Students list skills they can teach and skills they want to learn, get matched with mutual swap partners, send exchange requests, chat in real time, and track active exchanges — all on a serverless cloud backend.

---

## ✨ Features

- Student registration & login (Supabase Authentication)
- Editable student profiles (college, department, year, bio, availability)
- Add / remove skills you offer and skills you want, by category & level
- Explore page — search & filter students by skill/category
- **Smart Matching algorithm** — Mutual (100%) vs Potential (50%) matches
- Send / accept / reject exchange requests
- Active Exchange tracking (session date, notes, status progression)
- Real-time-capable messaging between students
- Notifications with read/unread state
- Admin dashboard — platform stats, manage students & skills, view exchanges, demand report
- Fully responsive pastel UI (desktop, tablet, mobile)
- **Runs instantly in Demo Mode** — no backend setup required to try it

---

## 🧱 Tech Stack

| Layer | Technology |
|---|---|
| Frontend | HTML5, CSS3, Vanilla JavaScript (no frameworks) |
| Backend / Database | Supabase (PostgreSQL) |
| Auth | Supabase Authentication |
| File storage | Supabase Storage (avatars) |
| Realtime | Supabase Realtime (live messages) |

No React, Angular, Vue, Node.js server, Firebase, Flask, or Django is used — the frontend talks directly to Supabase from the browser using `@supabase/supabase-js`.

---

## 📁 Project Structure

```text
skillswap-cloud/
├── index.html          Homepage
├── login.html           Login
├── register.html         Sign up
├── dashboard.html         Student dashboard
├── profile.html           View / edit profile
├── skills.html            Manage offered/wanted skills
├── explore.html           Search & discover students
├── matches.html           Smart matching results
├── requests.html          Received / sent exchange requests
├── exchange.html          Active exchange tracker
├── messages.html          Realtime chat
├── notifications.html     Notification center
├── admin.html             Admin dashboard
├── css/
│   └── style.css          Global pastel design system
├── js/
│   ├── config.js           Supabase URL / anon key (edit this)
│   ├── supabaseClient.js   Supabase client bootstrap
│   ├── store.js            Data access layer (Supabase + demo fallback)
│   ├── demoData.js         Seed data for zero-setup demo mode
│   ├── matching.js         Smart matching algorithm
│   ├── nav.js               Sidebar / navbar / auth-guard helpers
│   ├── toast.js             Toast & confirm-dialog UI
│   └── validate.js          Form validation helpers
├── assets/                  Icons / images (optional)
├── database/
│   └── schema.sql            Full schema, RLS policies, seed skills
└── README.md
```

---

## 🚀 Quick Start — Demo Mode (0 setup)

The project ships in **Demo Mode** by default: all data is stored in your browser's `localStorage`, pre-seeded with fictional students, skills, requests, an active exchange, messages and notifications — so every feature is clickable immediately.

1. Download / clone this folder.
2. Open `index.html` in a browser (or serve it — see below).
3. Click **Login** and use:
   - Email: `you@demo.skillswap.edu`
   - Password: `demo1234`
4. Explore the dashboard, matches, requests, messages, and admin dashboard.

> Serving over a local web server (rather than `file://`) is recommended so relative paths and any future `fetch` calls behave consistently:
> ```bash
> npx serve .
> # or
> python3 -m http.server 8080
> ```

---

## ☁️ Full Setup — Connect Real Supabase Backend

### 1. Create a Supabase project
Go to [supabase.com](https://supabase.com) → **New project** → choose a name, password, and region.

### 2. Run the database schema
Open **SQL Editor** in your Supabase dashboard → **New query** → paste the entire contents of `database/schema.sql` → **Run**.

This creates all seven tables (`profiles`, `skills`, `student_skills`, `exchange_requests`, `exchanges`, `messages`, `notifications`, `admins`), enables **Row Level Security** with policies scoping each student to their own data, indexes, the `is_admin()` helper, and seeds the skill catalog.

### 3. Enable Realtime on messages
The schema script already runs:
```sql
alter publication supabase_realtime add table messages;
```
If it errors because it's already enabled, that's fine — it just means Realtime is on.

### 4. Get your API credentials
**Project Settings → API**. Copy:
- **Project URL**
- **anon / public** key (⚠️ never copy the `service_role` key into frontend code)

### 5. Configure the frontend
Edit `js/config.js`:
```js
const SUPABASE_CONFIG = {
  url: "https://YOUR-PROJECT-REF.supabase.co",
  anonKey: "YOUR-SUPABASE-ANON-PUBLIC-KEY",
};
```
Once real values are set, `IS_DEMO_MODE` automatically becomes `false` and every page switches to live Supabase calls — no other code changes needed.

### 6. (Optional) Enable email confirmation / storage for avatars
- **Authentication → Providers → Email**: configure confirmation emails as desired for your demo.
- **Storage → New bucket** named `avatars` (public) if you want profile picture uploads; wire an upload handler in `profile.html` using `supabaseClient.storage.from('avatars').upload(...)`.

### 7. Make a student an admin
After a student registers, run in SQL Editor:
```sql
insert into admins (user_id) values ('<their-auth-user-uuid>');
```
Find the UUID under **Authentication → Users**.

---

## 🤝 How the Smart Matching Algorithm Works

For the logged-in student vs. every other student (`js/matching.js`):

1. **Condition A** — does the current student's *offered* skill list intersect the other student's *wanted* skill list?
2. **Condition B** — does the current student's *wanted* skill list intersect the other student's *offered* skill list?

| A | B | Result | Compatibility |
|---|---|---|---|
| ✅ | ✅ | **Mutual Skill Match** | 100% |
| ✅ or ✅ | one only | **Potential Match** | 50% |
| ❌ | ❌ | Not shown | — |

Matches are ranked mutual-first and rendered as cards with a compatibility ring and a one-click **Send Exchange Request** button.

---

## 🔐 Security Notes

- Row Level Security is enabled on every table; students can only edit their own profile/skills, and only view/act on requests, exchanges, and messages they're part of.
- Admin-only writes (deleting catalog skills, viewing the admin table) are gated behind an `is_admin()` check backed by an `admins` allow-list table.
- The **anon key** is safe for frontend use by design; the **service_role key must never** appear in any HTML/JS file.

---

## 📦 Deployment

Because this is a 100% static frontend, you can deploy it to any static host:

**Netlify**
1. Drag-and-drop the `skillswap-cloud/` folder into Netlify's dashboard, or connect your GitHub repo.
2. No build command needed — publish directory is the project root.

**Vercel**
1. `vercel` → follow prompts → framework preset "Other" → output directory `.`

**GitHub Pages**
1. Push the folder to a GitHub repo.
2. Repo **Settings → Pages** → deploy from the `main` branch, root folder.

**Supabase / any static bucket**
Any static file host works — the app only needs to reach your Supabase project over HTTPS, which is already CORS-enabled by default.

Remember to update `js/config.js` with your production Supabase credentials before deploying, and to enable email confirmations / restrict sign-ups in Supabase Auth settings as appropriate for your demo or class submission.

---

## 🧪 Demo Data Summary

Demo Mode seeds 5 fictional students (including "You"), the full 13-skill catalog from the spec, 2 pending exchange requests, 1 active exchange (Learning Started), a short chat thread, and 3 notifications — enough to demonstrate every screen without any manual data entry.

---

## 📄 License

Built as an academic mini-project. Free to use and adapt for coursework and demonstrations.
