-- =========================================================
-- SkillSwap Cloud — Supabase / PostgreSQL Schema
-- -----------------------------------------------------------
-- Run this entire file in the Supabase SQL Editor
-- (Project -> SQL Editor -> New query) once, top to bottom.
-- =========================================================

-- Needed for gen_random_uuid()
create extension if not exists "pgcrypto";

-- =========================================================
-- 1. TABLES
-- =========================================================

-- profiles: one row per student, id matches auth.users.id
create table if not exists profiles (
  id            uuid primary key references auth.users(id) on delete cascade,
  full_name     text not null,
  email         text not null unique,
  college       text,
  department    text,
  year          text,
  bio           text default '',
  avatar_url    text default '',
  availability  text default '',
  created_at    timestamptz not null default now()
);

-- skills: master catalog of skills students can offer/want
create table if not exists skills (
  id            uuid primary key default gen_random_uuid(),
  skill_name    text not null unique,
  category      text not null,
  description   text default ''
);

-- student_skills: join table — a student's offered/wanted skills
create table if not exists student_skills (
  id            uuid primary key default gen_random_uuid(),
  student_id    uuid not null references profiles(id) on delete cascade,
  skill_id      uuid not null references skills(id) on delete cascade,
  skill_type    text not null check (skill_type in ('offer', 'want')),
  skill_level   text not null check (skill_level in ('Beginner', 'Intermediate', 'Advanced')),
  created_at    timestamptz not null default now(),
  unique (student_id, skill_id, skill_type)
);

-- exchange_requests: a student requesting a skill swap with another
create table if not exists exchange_requests (
  id            uuid primary key default gen_random_uuid(),
  sender_id     uuid not null references profiles(id) on delete cascade,
  receiver_id   uuid not null references profiles(id) on delete cascade,
  offered_skill text not null,
  wanted_skill  text not null,
  message       text default '',
  status        text not null default 'Pending' check (status in ('Pending', 'Accepted', 'Rejected')),
  created_at    timestamptz not null default now()
);

-- exchanges: created automatically when a request is accepted
create table if not exists exchanges (
  id             uuid primary key default gen_random_uuid(),
  request_id     uuid references exchange_requests(id) on delete set null,
  student1_id    uuid not null references profiles(id) on delete cascade,
  student2_id    uuid not null references profiles(id) on delete cascade,
  student1_skill text not null,
  student2_skill text not null,
  status         text not null default 'Accepted' check (status in ('Accepted', 'Learning Started', 'Completed')),
  session_date   date,
  notes          text default '',
  created_at     timestamptz not null default now()
);

-- messages: direct messages between two students
create table if not exists messages (
  id            uuid primary key default gen_random_uuid(),
  sender_id     uuid not null references profiles(id) on delete cascade,
  receiver_id   uuid not null references profiles(id) on delete cascade,
  message       text not null,
  created_at    timestamptz not null default now()
);

-- notifications: in-app notifications per user
create table if not exists notifications (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid not null references profiles(id) on delete cascade,
  message       text not null,
  type          text not null check (type in ('request', 'accepted', 'rejected', 'message', 'completed')),
  is_read       boolean not null default false,
  created_at    timestamptz not null default now()
);

-- admins: whitelist of user ids allowed to access admin-only data
create table if not exists admins (
  user_id       uuid primary key references profiles(id) on delete cascade
);

-- =========================================================
-- 2. INDEXES
-- =========================================================
create index if not exists idx_student_skills_student on student_skills(student_id);
create index if not exists idx_student_skills_skill on student_skills(skill_id);
create index if not exists idx_requests_sender on exchange_requests(sender_id);
create index if not exists idx_requests_receiver on exchange_requests(receiver_id);
create index if not exists idx_exchanges_s1 on exchanges(student1_id);
create index if not exists idx_exchanges_s2 on exchanges(student2_id);
create index if not exists idx_messages_sender on messages(sender_id);
create index if not exists idx_messages_receiver on messages(receiver_id);
create index if not exists idx_notifications_user on notifications(user_id);

-- =========================================================
-- 3. ROW LEVEL SECURITY
-- =========================================================
alter table profiles          enable row level security;
alter table skills             enable row level security;
alter table student_skills     enable row level security;
alter table exchange_requests  enable row level security;
alter table exchanges          enable row level security;
alter table messages           enable row level security;
alter table notifications      enable row level security;
alter table admins             enable row level security;

-- Helper: is the current user an admin?
create or replace function is_admin() returns boolean as $$
  select exists (select 1 from admins where user_id = auth.uid());
$$ language sql stable security definer;

-- ---------- profiles ----------
create policy "Profiles are viewable by any authenticated student"
  on profiles for select
  using (auth.role() = 'authenticated');

create policy "Students can insert their own profile"
  on profiles for insert
  with check (auth.uid() = id);

create policy "Students can update their own profile"
  on profiles for update
  using (auth.uid() = id)
  with check (auth.uid() = id);

-- ---------- skills (public catalog, admin-managed writes) ----------
create policy "Skill catalog is viewable by any authenticated student"
  on skills for select
  using (auth.role() = 'authenticated');

create policy "Authenticated students can add new catalog skills"
  on skills for insert
  with check (auth.role() = 'authenticated');

create policy "Only admins can modify skill catalog entries"
  on skills for update
  using (is_admin());

create policy "Only admins can delete skill catalog entries"
  on skills for delete
  using (is_admin());

-- ---------- student_skills ----------
create policy "Student skills are viewable by any authenticated student"
  on student_skills for select
  using (auth.role() = 'authenticated');

create policy "Students can add their own skills"
  on student_skills for insert
  with check (auth.uid() = student_id);

create policy "Students can update their own skills"
  on student_skills for update
  using (auth.uid() = student_id);

create policy "Students can delete their own skills"
  on student_skills for delete
  using (auth.uid() = student_id);

-- ---------- exchange_requests ----------
create policy "Students can view requests involving them"
  on exchange_requests for select
  using (auth.uid() = sender_id or auth.uid() = receiver_id or is_admin());

create policy "Students can create requests as themselves"
  on exchange_requests for insert
  with check (auth.uid() = sender_id);

create policy "Receivers can update status of requests sent to them"
  on exchange_requests for update
  using (auth.uid() = receiver_id);

-- ---------- exchanges ----------
create policy "Students can view exchanges involving them"
  on exchanges for select
  using (auth.uid() = student1_id or auth.uid() = student2_id or is_admin());

create policy "Students can create exchanges involving themselves"
  on exchanges for insert
  with check (auth.uid() = student1_id or auth.uid() = student2_id);

create policy "Students can update exchanges involving them"
  on exchanges for update
  using (auth.uid() = student1_id or auth.uid() = student2_id);

-- ---------- messages ----------
create policy "Students can view their own conversations"
  on messages for select
  using (auth.uid() = sender_id or auth.uid() = receiver_id);

create policy "Students can send messages as themselves"
  on messages for insert
  with check (auth.uid() = sender_id);

-- ---------- notifications ----------
create policy "Students can view their own notifications"
  on notifications for select
  using (auth.uid() = user_id);

create policy "System/users can insert notifications for any recipient"
  on notifications for insert
  with check (auth.role() = 'authenticated');

create policy "Students can mark their own notifications as read"
  on notifications for update
  using (auth.uid() = user_id);

-- ---------- admins ----------
create policy "Only admins can view the admin list"
  on admins for select
  using (is_admin());

-- =========================================================
-- 4. REALTIME
-- =========================================================
-- Enable Realtime replication for the messages table so the
-- Messages page can receive INSERTs live (Database -> Replication
-- in the Supabase dashboard, or run):
alter publication supabase_realtime add table messages;

-- =========================================================
-- 5. DEMO / SEED DATA (skills catalog only — safe to run
--    anytime; profiles must be created via Supabase Auth sign-up
--    so foreign keys to auth.users resolve correctly)
-- =========================================================
insert into skills (skill_name, category) values
  ('Python', 'Programming'),
  ('Java', 'Programming'),
  ('C', 'Programming'),
  ('HTML/CSS', 'Web Development'),
  ('JavaScript', 'Web Development'),
  ('SQL', 'Database'),
  ('Cloud Computing', 'Cloud Computing'),
  ('Machine Learning', 'AI & ML'),
  ('Data Science', 'Data Science'),
  ('UI/UX Design', 'Design'),
  ('Cybersecurity', 'Cybersecurity'),
  ('Communication', 'Communication'),
  ('Public Speaking', 'Communication')
on conflict (skill_name) do nothing;

-- To make a signed-up user an admin, run (after they've registered):
-- insert into admins (user_id) values ('<their-auth-user-uuid>');
