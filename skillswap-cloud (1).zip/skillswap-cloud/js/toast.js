/* =========================================================
   SkillSwap Cloud — Toast Notifications
========================================================= */

function ensureToastRegion() {
  let region = document.getElementById("toast-region");
  if (!region) {
    region = document.createElement("div");
    region.id = "toast-region";
    document.body.appendChild(region);
  }
  return region;
}

function showToast(message, type = "success", duration = 3500) {
  const region = ensureToastRegion();
  const icons = { success: "✓", error: "⚠", info: "ℹ" };
  const toast = document.createElement("div");
  toast.className = `toast ${type}`;
  toast.innerHTML = `<span>${icons[type] || ""}</span><span>${message}</span>`;
  region.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = "0";
    toast.style.transform = "translateX(30px)";
    toast.style.transition = "all .25s ease";
    setTimeout(() => toast.remove(), 250);
  }, duration);
}

function showConfirm(message) {
  return new Promise((resolve) => {
    const overlay = document.createElement("div");
    overlay.className = "modal-overlay open";
    overlay.innerHTML = `
      <div class="modal">
        <h3>Please confirm</h3>
        <p class="text-muted">${message}</p>
        <div class="modal-actions">
          <button class="btn btn-secondary" data-action="cancel">Cancel</button>
          <button class="btn btn-primary" data-action="ok">Confirm</button>
        </div>
      </div>`;
    document.body.appendChild(overlay);
    overlay.addEventListener("click", (e) => {
      if (e.target === overlay) { overlay.remove(); resolve(false); }
      const action = e.target.getAttribute("data-action");
      if (action === "ok") { overlay.remove(); resolve(true); }
      if (action === "cancel") { overlay.remove(); resolve(false); }
    });
  });
}
