/* =========================================================
   SkillSwap Cloud — Navigation helpers
========================================================= */

/* Public navbar mobile toggle (index.html) */
function initPublicNav() {
  const toggle = document.getElementById("navToggle");
  const links = document.getElementById("navLinks");
  if (!toggle || !links) return;
  toggle.addEventListener("click", () => links.classList.toggle("open"));
}

/* Sidebar mobile toggle (dashboard layout pages) */
function initSidebar() {
  const toggle = document.getElementById("sidebarToggle");
  const sidebar = document.getElementById("sidebar");
  if (!toggle || !sidebar) return;
  toggle.addEventListener("click", () => sidebar.classList.toggle("open"));
  document.addEventListener("click", (e) => {
    if (window.innerWidth > 900) return;
    if (!sidebar.contains(e.target) && !toggle.contains(e.target)) {
      sidebar.classList.remove("open");
    }
  });
}

/* Guards a dashboard page: redirects to login.html if no session.
   Returns the current user's profile. */
async function requireAuth() {
  const userId = await Store.auth.getSessionUserId();
  if (!userId) {
    window.location.href = "login.html";
    return null;
  }
  try {
    const profile = await Store.profiles.getById(userId);
    if (!profile) {
      window.location.href = "login.html";
      return null;
    }
    paintUserChip(profile);
    return profile;
  } catch (e) {
    window.location.href = "login.html";
    return null;
  }
}

function paintUserChip(profile) {
  document.querySelectorAll("[data-user-name]").forEach((el) => (el.textContent = profile.full_name));
  document.querySelectorAll("[data-user-college]").forEach((el) => (el.textContent = profile.college || ""));
  document.querySelectorAll("[data-user-initials]").forEach((el) => (el.textContent = initials(profile.full_name)));
}

function initials(name = "") {
  return name.trim().split(/\s+/).slice(0, 2).map((n) => n[0]?.toUpperCase() || "").join("");
}

function wireLogout() {
  document.querySelectorAll("[data-logout]").forEach((btn) => {
    btn.addEventListener("click", async (e) => {
      e.preventDefault();
      await Store.auth.logout();
      window.location.href = "login.html";
    });
  });
}

function timeAgo(dateStr) {
  const diffMs = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  if (days < 30) return `${days}d ago`;
  return new Date(dateStr).toLocaleDateString();
}

function escapeHtml(str = "") {
  return str.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
