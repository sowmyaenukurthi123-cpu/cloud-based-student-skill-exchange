/* =========================================================
   SkillSwap Cloud — Smart Matching Algorithm
   -----------------------------------------------------------
   For the current student vs. every other student:
     condition A = current student's OFFERED skills intersect
                   the other student's WANTED skills
     condition B = current student's WANTED skills intersect
                   the other student's OFFERED skills

     A && B  -> "Mutual Skill Match"  compatibility 100%
     A || B  -> "Potential Match"     compatibility 50%
     neither -> not a match, excluded
========================================================= */

function skillNameSet(studentSkillRows, type) {
  return new Set(
    studentSkillRows
      .filter((r) => r.skill_type === type)
      .map((r) => (r.skill ? r.skill.skill_name : r.skill_name))
  );
}

function intersect(setA, setB) {
  return [...setA].filter((x) => setB.has(x));
}

/**
 * @param {Array} myRows   current student's student_skills rows (joined with skill)
 * @param {Object} otherStudent   { profile, rows }
 * @returns {Object|null} match result
 */
function computeMatch(myRows, otherRows) {
  const myOffer = skillNameSet(myRows, "offer");
  const myWant = skillNameSet(myRows, "want");
  const theirOffer = skillNameSet(otherRows, "offer");
  const theirWant = skillNameSet(otherRows, "want");

  const iTeachThemWhatTheyWant = intersect(myOffer, theirWant); // condition A
  const theyTeachMeWhatIWant = intersect(theirOffer, myWant); // condition B

  const condA = iTeachThemWhatTheyWant.length > 0;
  const condB = theyTeachMeWhatIWant.length > 0;

  if (!condA && !condB) return null;

  return {
    type: condA && condB ? "mutual" : "potential",
    compatibility: condA && condB ? 100 : 50,
    youTeach: iTeachThemWhatTheyWant[0] || null,
    youLearn: theyTeachMeWhatIWant[0] || null,
    allTeach: iTeachThemWhatTheyWant,
    allLearn: theyTeachMeWhatIWant,
  };
}

/**
 * Builds a ranked list of matches for the current student against all others.
 * @param {string} myId
 * @returns {Promise<Array>} sorted matches, mutual first
 */
async function buildMatchesForStudent(myId) {
  const myRows = await Store.studentSkills.listByStudent(myId);
  const others = await Store.profiles.listAll(myId);

  const results = [];
  for (const other of others) {
    const otherRows = await Store.studentSkills.listByStudent(other.id);
    const match = computeMatch(myRows, otherRows);
    if (match) results.push({ student: other, ...match });
  }

  results.sort((a, b) => b.compatibility - a.compatibility);
  return results;
}
