/* =========================================================
   SkillSwap Cloud — Demo Seed Data
   Used only when running in DEMO MODE (no Supabase configured).
   Everything lives in the browser's localStorage under
   "skillswap_demo_db" so the project is fully clickable and
   demoable with zero backend setup.
========================================================= */

const DEMO_DB_KEY = "skillswap_demo_db";
const DEMO_SESSION_KEY = "skillswap_demo_session";

const SKILL_CATALOG = [
  { id: "sk-python", skill_name: "Python", category: "Programming" },
  { id: "sk-java", skill_name: "Java", category: "Programming" },
  { id: "sk-c", skill_name: "C", category: "Programming" },
  { id: "sk-htmlcss", skill_name: "HTML/CSS", category: "Web Development" },
  { id: "sk-js", skill_name: "JavaScript", category: "Web Development" },
  { id: "sk-sql", skill_name: "SQL", category: "Database" },
  { id: "sk-cloud", skill_name: "Cloud Computing", category: "Cloud Computing" },
  { id: "sk-ml", skill_name: "Machine Learning", category: "AI & ML" },
  { id: "sk-ds", skill_name: "Data Science", category: "Data Science" },
  { id: "sk-uiux", skill_name: "UI/UX Design", category: "Design" },
  { id: "sk-cyber", skill_name: "Cybersecurity", category: "Cybersecurity" },
  { id: "sk-comm", skill_name: "Communication", category: "Communication" },
  { id: "sk-speak", skill_name: "Public Speaking", category: "Communication" },
];

function seedDemoDatabase() {
  const existing = localStorage.getItem(DEMO_DB_KEY);
  if (existing) return JSON.parse(existing);

  const now = new Date().toISOString();

  const profiles = [
    {
      id: "demo-you",
      full_name: "You (Demo Student)",
      email: "you@demo.skillswap.edu",
      password: "demo1234",
      college: "SkillSwap Institute of Technology",
      department: "Computer Science & Engineering",
      year: "3rd Year",
      bio: "CSE student exploring cloud computing and web development. Happy to trade Python & SQL knowledge for design skills!",
      avatar_url: "",
      availability: "Weekday evenings, weekends",
      created_at: now,
    },
    {
      id: "demo-anita",
      full_name: "Anita Sharma",
      email: "anita@demo.skillswap.edu",
      password: "demo1234",
      college: "Nova Engineering College",
      department: "Information Technology",
      year: "2nd Year",
      bio: "UI/UX enthusiast who loves clean design systems. Looking to pick up backend & cloud skills.",
      avatar_url: "",
      availability: "Weekends",
      created_at: now,
    },
    {
      id: "demo-ravi",
      full_name: "Ravi Kumar",
      email: "ravi@demo.skillswap.edu",
      college: "Nova Engineering College",
      department: "Computer Science",
      year: "4th Year",
      bio: "Machine learning hobbyist, built a few Kaggle projects. Want to sharpen my public speaking.",
      avatar_url: "",
      availability: "Evenings after 6 PM",
      password: "demo1234",
      created_at: now,
    },
    {
      id: "demo-meera",
      full_name: "Meera Iyer",
      email: "meera@demo.skillswap.edu",
      college: "Lakeview Institute of Tech",
      department: "Electronics & CS",
      year: "3rd Year",
      bio: "Cybersecurity fan, CTF player. Want to get better at cloud computing and Java.",
      avatar_url: "",
      availability: "Late nights, weekends",
      password: "demo1234",
      created_at: now,
    },
    {
      id: "demo-farhan",
      full_name: "Farhan Ali",
      email: "farhan@demo.skillswap.edu",
      college: "SkillSwap Institute of Technology",
      department: "Data Science",
      year: "2nd Year",
      bio: "Data science major who wants to teach SQL & Data Science, and learn UI/UX design.",
      avatar_url: "",
      availability: "Weekday mornings",
      password: "demo1234",
      created_at: now,
    },
  ];

  const student_skills = [
    // You (demo-you): offer Python, SQL, Cloud Computing | want UI/UX Design, Machine Learning
    { id: "ss1", student_id: "demo-you", skill_id: "sk-python", skill_type: "offer", skill_level: "Advanced" },
    { id: "ss2", student_id: "demo-you", skill_id: "sk-sql", skill_type: "offer", skill_level: "Intermediate" },
    { id: "ss3", student_id: "demo-you", skill_id: "sk-cloud", skill_type: "offer", skill_level: "Intermediate" },
    { id: "ss4", student_id: "demo-you", skill_id: "sk-uiux", skill_type: "want", skill_level: "Beginner" },
    { id: "ss5", student_id: "demo-you", skill_id: "sk-ml", skill_type: "want", skill_level: "Beginner" },

    // Anita: offer UI/UX Design, HTML/CSS | want Cloud Computing, Python  -> MUTUAL match with You
    { id: "ss6", student_id: "demo-anita", skill_id: "sk-uiux", skill_type: "offer", skill_level: "Advanced" },
    { id: "ss7", student_id: "demo-anita", skill_id: "sk-htmlcss", skill_type: "offer", skill_level: "Advanced" },
    { id: "ss8", student_id: "demo-anita", skill_id: "sk-cloud", skill_type: "want", skill_level: "Beginner" },
    { id: "ss9", student_id: "demo-anita", skill_id: "sk-python", skill_type: "want", skill_level: "Beginner" },

    // Ravi: offer Machine Learning, Data Science | want Public Speaking, Communication -> Potential match
    { id: "ss10", student_id: "demo-ravi", skill_id: "sk-ml", skill_type: "offer", skill_level: "Intermediate" },
    { id: "ss11", student_id: "demo-ravi", skill_id: "sk-ds", skill_type: "offer", skill_level: "Intermediate" },
    { id: "ss12", student_id: "demo-ravi", skill_id: "sk-speak", skill_type: "want", skill_level: "Beginner" },

    // Meera: offer Cybersecurity | want Cloud Computing, Java -> Potential match (wants your Cloud)
    { id: "ss13", student_id: "demo-meera", skill_id: "sk-cyber", skill_type: "offer", skill_level: "Advanced" },
    { id: "ss14", student_id: "demo-meera", skill_id: "sk-cloud", skill_type: "want", skill_level: "Beginner" },
    { id: "ss15", student_id: "demo-meera", skill_id: "sk-java", skill_type: "want", skill_level: "Beginner" },

    // Farhan: offer SQL, Data Science | want UI/UX Design
    { id: "ss16", student_id: "demo-farhan", skill_id: "sk-sql", skill_type: "offer", skill_level: "Advanced" },
    { id: "ss17", student_id: "demo-farhan", skill_id: "sk-ds", skill_type: "offer", skill_level: "Advanced" },
    { id: "ss18", student_id: "demo-farhan", skill_id: "sk-uiux", skill_type: "want", skill_level: "Beginner" },
  ];

  const exchange_requests = [
    {
      id: "req1",
      sender_id: "demo-meera",
      receiver_id: "demo-you",
      offered_skill: "Cybersecurity",
      wanted_skill: "Cloud Computing",
      message: "Hi! I'd love to learn Cloud Computing from you in exchange for Cybersecurity basics.",
      status: "Pending",
      created_at: now,
    },
    {
      id: "req2",
      sender_id: "demo-you",
      receiver_id: "demo-farhan",
      offered_skill: "Python",
      wanted_skill: "SQL",
      message: "Hey Farhan, want to trade Python lessons for your SQL expertise?",
      status: "Pending",
      created_at: now,
    },
  ];

  const exchanges = [
    {
      id: "ex1",
      request_id: "req0",
      student1_id: "demo-you",
      student2_id: "demo-anita",
      student1_skill: "Python",
      student2_skill: "UI/UX Design",
      status: "Learning Started",
      session_date: "",
      notes: "First session covered Figma basics. Next: component libraries.",
      created_at: now,
    },
  ];

  const messages = [
    { id: "m1", sender_id: "demo-anita", receiver_id: "demo-you", message: "Hey! Excited to start our skill swap 🎉", created_at: now },
    { id: "m2", sender_id: "demo-you", receiver_id: "demo-anita", message: "Same here! Free this weekend for a Figma session?", created_at: now },
    { id: "m3", sender_id: "demo-anita", receiver_id: "demo-you", message: "Yes, Saturday 5 PM works for me.", created_at: now },
  ];

  const notifications = [
    { id: "n1", user_id: "demo-you", message: "Meera Sharma sent you an exchange request for Cloud Computing.", type: "request", is_read: false, created_at: now },
    { id: "n2", user_id: "demo-you", message: "Anita Sharma accepted your exchange request!", type: "accepted", is_read: false, created_at: now },
    { id: "n3", user_id: "demo-you", message: "New message from Anita Sharma.", type: "message", is_read: true, created_at: now },
  ];

  const db = {
    profiles,
    skills: SKILL_CATALOG,
    student_skills,
    exchange_requests,
    exchanges,
    messages,
    notifications,
  };

  localStorage.setItem(DEMO_DB_KEY, JSON.stringify(db));
  return db;
}

function getDemoDb() {
  return seedDemoDatabase();
}

function saveDemoDb(db) {
  localStorage.setItem(DEMO_DB_KEY, JSON.stringify(db));
}

function demoUid(prefix) {
  return prefix + "-" + Math.random().toString(36).slice(2, 10);
}
