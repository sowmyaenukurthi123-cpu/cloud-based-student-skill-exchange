/* =========================================================
   SkillSwap Cloud — Supabase Client Bootstrap
   Loaded after https://unpkg.com/@supabase/supabase-js (see
   the <script> tag in each HTML page) and after config.js.
========================================================= */

let supabaseClient = null;

if (!IS_DEMO_MODE && window.supabase) {
  supabaseClient = window.supabase.createClient(
    SUPABASE_CONFIG.url,
    SUPABASE_CONFIG.anonKey,
    {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
      },
    }
  );
}
