/* =========================================================
   SkillSwap Cloud — Form Validation Helpers
========================================================= */

function markInvalid(fieldEl, message) {
  fieldEl.classList.add("invalid");
  const err = fieldEl.querySelector(".field-error");
  if (err) err.textContent = message;
}

function clearInvalid(fieldEl) {
  fieldEl.classList.remove("invalid");
}

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function validateRequired(formEl, rules) {
  // rules: [{ input: '#email', wrapper: '.field', validator: fn, message: '...' }]
  let valid = true;
  rules.forEach(({ input, wrapper, validator, message }) => {
    const inputEl = formEl.querySelector(input);
    const wrapEl = formEl.querySelector(wrapper);
    const value = inputEl.value.trim();
    const ok = validator ? validator(value) : value.length > 0;
    if (!ok) {
      markInvalid(wrapEl, message);
      valid = false;
    } else {
      clearInvalid(wrapEl);
    }
  });
  return valid;
}
