/* =========================================================
   SkillSwap Cloud — Data Store
   A single abstraction every page calls. In production
   (Supabase configured) it talks to Postgres via Supabase JS.
   In demo mode it talks to localStorage using the exact same
   table/column shape defined in database/schema.sql, so the
   Supabase code paths below are the real implementation, not
   an afterthought.
========================================================= */

const Store = {

  /* ---------------- AUTH ---------------- */
  auth: {
    async register({ full_name, email, password, college, department, year }) {
      if (IS_DEMO_MODE) {
        const db = getDemoDb();
        if (db.profiles.some((p) => p.email.toLowerCase() === email.toLowerCase())) {
          throw new Error("An account with this email already exists.");
        }
        const id = demoUid("stu");
        db.profiles.push({
          id, full_name, email, password, college, department, year,
          bio: "", avatar_url: "", availability: "",
          created_at: new Date().toISOString(),
        });
        saveDemoDb(db);
        localStorage.setItem(DEMO_SESSION_KEY, id);
        return { id };
      }

      const { data, error } = await supabaseClient.auth.signUp({ email, password });
      if (error) throw error;
      const userId = data.user.id;
      const { error: profileError } = await supabaseClient.from("profiles").insert({
        id: userId, full_name, email, college, department, year,
      });
      if (profileError) throw profileError;
      return { id: userId };
    },

    async login(email, password) {
      if (IS_DEMO_MODE) {
        const db = getDemoDb();
        const user = db.profiles.find(
          (p) => p.email.toLowerCase() === email.toLowerCase() && p.password === password
        );
        if (!user) throw new Error("Invalid email or password.");
        localStorage.setItem(DEMO_SESSION_KEY, user.id);
        return user;
      }

      const { data, error } = await supabaseClient.auth.signInWithPassword({ email, password });
      if (error) throw error;
      return data.user;
    },

    async logout() {
      if (IS_DEMO_MODE) {
        localStorage.removeItem(DEMO_SESSION_KEY);
        return;
      }
      await supabaseClient.auth.signOut();
    },

    async getSessionUserId() {
      if (IS_DEMO_MODE) {
        return localStorage.getItem(DEMO_SESSION_KEY);
      }
      const { data } = await supabaseClient.auth.getSession();
      return data.session ? data.session.user.id : null;
    },
  },

  /* ---------------- PROFILES ---------------- */
  profiles: {
    async getById(id) {
      if (IS_DEMO_MODE) {
        const db = getDemoDb();
        return db.profiles.find((p) => p.id === id) || null;
      }
      const { data, error } = await supabaseClient.from("profiles").select("*").eq("id", id).single();
      if (error) throw error;
      return data;
    },

    async update(id, fields) {
      if (IS_DEMO_MODE) {
        const db = getDemoDb();
        const idx = db.profiles.findIndex((p) => p.id === id);
        if (idx === -1) throw new Error("Profile not found.");
        db.profiles[idx] = { ...db.profiles[idx], ...fields };
        saveDemoDb(db);
        return db.profiles[idx];
      }
      const { data, error } = await supabaseClient.from("profiles").update(fields).eq("id", id).select().single();
      if (error) throw error;
      return data;
    },

    async listAll(excludeId) {
      if (IS_DEMO_MODE) {
        const db = getDemoDb();
        return db.profiles.filter((p) => p.id !== excludeId);
      }
      const query = supabaseClient.from("profiles").select("*");
      const { data, error } = excludeId ? await query.neq("id", excludeId) : await query;
      if (error) throw error;
      return data;
    },
  },

  /* ---------------- SKILLS CATALOG ---------------- */
  skills: {
    async listAll() {
      if (IS_DEMO_MODE) {
        return getDemoDb().skills;
      }
      const { data, error } = await supabaseClient.from("skills").select("*").order("skill_name");
      if (error) throw error;
      return data;
    },

    async findOrCreate(skill_name, category, description = "") {
      if (IS_DEMO_MODE) {
        const db = getDemoDb();
        let skill = db.skills.find((s) => s.skill_name.toLowerCase() === skill_name.toLowerCase());
        if (!skill) {
          skill = { id: demoUid("sk"), skill_name, category, description };
          db.skills.push(skill);
          saveDemoDb(db);
        }
        return skill;
      }
      const { data: existing } = await supabaseClient
        .from("skills").select("*").ilike("skill_name", skill_name).maybeSingle();
      if (existing) return existing;
      const { data, error } = await supabaseClient
        .from("skills").insert({ skill_name, category, description }).select().single();
      if (error) throw error;
      return data;
    },
  },

  /* ---------------- STUDENT SKILLS ---------------- */
  studentSkills: {
    async listByStudent(studentId) {
      if (IS_DEMO_MODE) {
        const db = getDemoDb();
        return db.student_skills
          .filter((ss) => ss.student_id === studentId)
          .map((ss) => ({ ...ss, skill: db.skills.find((s) => s.id === ss.skill_id) }));
      }
      const { data, error } = await supabaseClient
        .from("student_skills")
        .select("*, skill:skills(*)")
        .eq("student_id", studentId);
      if (error) throw error;
      return data;
    },

    async add(studentId, skill_name, category, skill_type, skill_level) {
      const skill = await Store.skills.findOrCreate(skill_name, category);
      if (IS_DEMO_MODE) {
        const db = getDemoDb();
        const dup = db.student_skills.find(
          (ss) => ss.student_id === studentId && ss.skill_id === skill.id && ss.skill_type === skill_type
        );
        if (dup) throw new Error("You already added this skill in this list.");
        const row = { id: demoUid("ss"), student_id: studentId, skill_id: skill.id, skill_type, skill_level };
        db.student_skills.push(row);
        saveDemoDb(db);
        return { ...row, skill };
      }
      const { data, error } = await supabaseClient
        .from("student_skills")
        .insert({ student_id: studentId, skill_id: skill.id, skill_type, skill_level })
        .select("*, skill:skills(*)")
        .single();
      if (error) throw error;
      return data;
    },

    async remove(rowId) {
      if (IS_DEMO_MODE) {
        const db = getDemoDb();
        db.student_skills = db.student_skills.filter((ss) => ss.id !== rowId);
        saveDemoDb(db);
        return;
      }
      const { error } = await supabaseClient.from("student_skills").delete().eq("id", rowId);
      if (error) throw error;
    },
  },

  /* ---------------- EXCHANGE REQUESTS ---------------- */
  requests: {
    async create({ sender_id, receiver_id, offered_skill, wanted_skill, message }) {
      const row = {
        sender_id, receiver_id, offered_skill, wanted_skill, message,
        status: "Pending", created_at: new Date().toISOString(),
      };
      if (IS_DEMO_MODE) {
        const db = getDemoDb();
        row.id = demoUid("req");
        db.exchange_requests.push(row);
        db.notifications.push({
          id: demoUid("n"), user_id: receiver_id,
          message: `New exchange request: ${offered_skill} ↔ ${wanted_skill}`,
          type: "request", is_read: false, created_at: row.created_at,
        });
        saveDemoDb(db);
        return row;
      }
      const { data, error } = await supabaseClient.from("exchange_requests").insert(row).select().single();
      if (error) throw error;
      await supabaseClient.from("notifications").insert({
        user_id: receiver_id, message: `New exchange request: ${offered_skill} ↔ ${wanted_skill}`, type: "request", is_read: false,
      });
      return data;
    },

    async listReceived(userId) {
      if (IS_DEMO_MODE) {
        const db = getDemoDb();
        return db.exchange_requests
          .filter((r) => r.receiver_id === userId)
          .map((r) => ({ ...r, sender: db.profiles.find((p) => p.id === r.sender_id) }))
          .sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
      }
      const { data, error } = await supabaseClient
        .from("exchange_requests").select("*, sender:profiles!exchange_requests_sender_id_fkey(*)")
        .eq("receiver_id", userId).order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },

    async listSent(userId) {
      if (IS_DEMO_MODE) {
        const db = getDemoDb();
        return db.exchange_requests
          .filter((r) => r.sender_id === userId)
          .map((r) => ({ ...r, receiver: db.profiles.find((p) => p.id === r.receiver_id) }))
          .sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
      }
      const { data, error } = await supabaseClient
        .from("exchange_requests").select("*, receiver:profiles!exchange_requests_receiver_id_fkey(*)")
        .eq("sender_id", userId).order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },

    async updateStatus(requestId, status) {
      if (IS_DEMO_MODE) {
        const db = getDemoDb();
        const req = db.exchange_requests.find((r) => r.id === requestId);
        if (!req) throw new Error("Request not found.");
        req.status = status;
        db.notifications.push({
          id: demoUid("n"), user_id: req.sender_id,
          message: `Your exchange request (${req.offered_skill} ↔ ${req.wanted_skill}) was ${status.toLowerCase()}.`,
          type: status === "Accepted" ? "accepted" : "rejected", is_read: false, created_at: new Date().toISOString(),
        });
        if (status === "Accepted") {
          db.exchanges.push({
            id: demoUid("ex"), request_id: req.id,
            student1_id: req.sender_id, student2_id: req.receiver_id,
            student1_skill: req.offered_skill, student2_skill: req.wanted_skill,
            status: "Accepted", session_date: "", notes: "",
            created_at: new Date().toISOString(),
          });
        }
        saveDemoDb(db);
        return req;
      }
      const { data, error } = await supabaseClient
        .from("exchange_requests").update({ status }).eq("id", requestId).select().single();
      if (error) throw error;
      if (status === "Accepted") {
        await supabaseClient.from("exchanges").insert({
          request_id: data.id, student1_id: data.sender_id, student2_id: data.receiver_id,
          student1_skill: data.offered_skill, student2_skill: data.wanted_skill, status: "Accepted",
        });
      }
      await supabaseClient.from("notifications").insert({
        user_id: data.sender_id,
        message: `Your exchange request (${data.offered_skill} ↔ ${data.wanted_skill}) was ${status.toLowerCase()}.`,
        type: status === "Accepted" ? "accepted" : "rejected", is_read: false,
      });
      return data;
    },
  },

  /* ---------------- ACTIVE EXCHANGES ---------------- */
  exchanges: {
    async listByStudent(userId) {
      if (IS_DEMO_MODE) {
        const db = getDemoDb();
        return db.exchanges
          .filter((e) => e.student1_id === userId || e.student2_id === userId)
          .map((e) => {
            const partnerId = e.student1_id === userId ? e.student2_id : e.student1_id;
            const youTeach = e.student1_id === userId ? e.student1_skill : e.student2_skill;
            const youLearn = e.student1_id === userId ? e.student2_skill : e.student1_skill;
            return { ...e, partner: db.profiles.find((p) => p.id === partnerId), youTeach, youLearn };
          })
          .sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
      }
      const { data, error } = await supabaseClient
        .from("exchanges")
        .select("*, s1:profiles!exchanges_student1_id_fkey(*), s2:profiles!exchanges_student2_id_fkey(*)")
        .or(`student1_id.eq.${userId},student2_id.eq.${userId}`);
      if (error) throw error;
      return data.map((e) => {
        const partner = e.student1_id === userId ? e.s2 : e.s1;
        const youTeach = e.student1_id === userId ? e.student1_skill : e.student2_skill;
        const youLearn = e.student1_id === userId ? e.student2_skill : e.student1_skill;
        return { ...e, partner, youTeach, youLearn };
      });
    },

    async update(exchangeId, fields) {
      if (IS_DEMO_MODE) {
        const db = getDemoDb();
        const idx = db.exchanges.findIndex((e) => e.id === exchangeId);
        if (idx === -1) throw new Error("Exchange not found.");
        db.exchanges[idx] = { ...db.exchanges[idx], ...fields };
        saveDemoDb(db);
        return db.exchanges[idx];
      }
      const { data, error } = await supabaseClient.from("exchanges").update(fields).eq("id", exchangeId).select().single();
      if (error) throw error;
      return data;
    },
  },

  /* ---------------- MESSAGES ---------------- */
  messages: {
    async listConversationsFor(userId) {
      if (IS_DEMO_MODE) {
        const db = getDemoDb();
        const partnerIds = new Set();
        db.messages.forEach((m) => {
          if (m.sender_id === userId) partnerIds.add(m.receiver_id);
          if (m.receiver_id === userId) partnerIds.add(m.sender_id);
        });
        return [...partnerIds].map((pid) => {
          const thread = db.messages
            .filter((m) => (m.sender_id === userId && m.receiver_id === pid) || (m.sender_id === pid && m.receiver_id === userId))
            .sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
          return { partner: db.profiles.find((p) => p.id === pid), lastMessage: thread[0] };
        }).sort((a, b) => new Date(b.lastMessage.created_at) - new Date(a.lastMessage.created_at));
      }
      const { data, error } = await supabaseClient
        .from("messages").select("*")
        .or(`sender_id.eq.${userId},receiver_id.eq.${userId}`)
        .order("created_at", { ascending: false });
      if (error) throw error;
      const partnerIds = [...new Set(data.map((m) => (m.sender_id === userId ? m.receiver_id : m.sender_id)))];
      const results = [];
      for (const pid of partnerIds) {
        const profile = await Store.profiles.getById(pid);
        const lastMessage = data.find((m) => m.sender_id === pid || m.receiver_id === pid);
        results.push({ partner: profile, lastMessage });
      }
      return results;
    },

    async listConversation(userId, partnerId) {
      if (IS_DEMO_MODE) {
        const db = getDemoDb();
        return db.messages
          .filter((m) => (m.sender_id === userId && m.receiver_id === partnerId) || (m.sender_id === partnerId && m.receiver_id === userId))
          .sort((a, b) => new Date(a.created_at) - new Date(b.created_at));
      }
      const { data, error } = await supabaseClient
        .from("messages").select("*")
        .or(`and(sender_id.eq.${userId},receiver_id.eq.${partnerId}),and(sender_id.eq.${partnerId},receiver_id.eq.${userId})`)
        .order("created_at", { ascending: true });
      if (error) throw error;
      return data;
    },

    async send(senderId, receiverId, message) {
      const row = { sender_id: senderId, receiver_id: receiverId, message, created_at: new Date().toISOString() };
      if (IS_DEMO_MODE) {
        const db = getDemoDb();
        row.id = demoUid("m");
        db.messages.push(row);
        db.notifications.push({
          id: demoUid("n"), user_id: receiverId, message: "New message received.",
          type: "message", is_read: false, created_at: row.created_at,
        });
        saveDemoDb(db);
        return row;
      }
      const { data, error } = await supabaseClient.from("messages").insert(row).select().single();
      if (error) throw error;
      await supabaseClient.from("notifications").insert({ user_id: receiverId, message: "New message received.", type: "message", is_read: false });
      return data;
    },

    /* Realtime subscription (Supabase only — no-op helper in demo mode) */
    subscribeToConversation(userId, partnerId, onInsert) {
      if (IS_DEMO_MODE || !supabaseClient) return null;
      const channel = supabaseClient
        .channel(`messages-${userId}-${partnerId}`)
        .on("postgres_changes", { event: "INSERT", schema: "public", table: "messages" }, (payload) => {
          const m = payload.new;
          const belongs = (m.sender_id === userId && m.receiver_id === partnerId) || (m.sender_id === partnerId && m.receiver_id === userId);
          if (belongs) onInsert(m);
        })
        .subscribe();
      return channel;
    },
  },

  /* ---------------- NOTIFICATIONS ---------------- */
  notifications: {
    async listFor(userId) {
      if (IS_DEMO_MODE) {
        const db = getDemoDb();
        return db.notifications.filter((n) => n.user_id === userId).sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
      }
      const { data, error } = await supabaseClient.from("notifications").select("*").eq("user_id", userId).order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },

    async markRead(id) {
      if (IS_DEMO_MODE) {
        const db = getDemoDb();
        const n = db.notifications.find((x) => x.id === id);
        if (n) n.is_read = true;
        saveDemoDb(db);
        return;
      }
      await supabaseClient.from("notifications").update({ is_read: true }).eq("id", id);
    },

    async markAllRead(userId) {
      if (IS_DEMO_MODE) {
        const db = getDemoDb();
        db.notifications.forEach((n) => { if (n.user_id === userId) n.is_read = true; });
        saveDemoDb(db);
        return;
      }
      await supabaseClient.from("notifications").update({ is_read: true }).eq("user_id", userId).eq("is_read", false);
    },
  },

  /* ---------------- ADMIN ---------------- */
  admin: {
    async stats() {
      if (IS_DEMO_MODE) {
        const db = getDemoDb();
        return {
          totalStudents: db.profiles.length,
          totalSkills: db.skills.length,
          totalExchanges: db.exchanges.length,
          activeExchanges: db.exchanges.filter((e) => e.status !== "Completed").length,
          pendingRequests: db.exchange_requests.filter((r) => r.status === "Pending").length,
        };
      }
      const [{ count: totalStudents }, { count: totalSkills }, { count: totalExchanges }, { count: activeExchanges }, { count: pendingRequests }] =
        await Promise.all([
          supabaseClient.from("profiles").select("*", { count: "exact", head: true }),
          supabaseClient.from("skills").select("*", { count: "exact", head: true }),
          supabaseClient.from("exchanges").select("*", { count: "exact", head: true }),
          supabaseClient.from("exchanges").select("*", { count: "exact", head: true }).neq("status", "Completed"),
          supabaseClient.from("exchange_requests").select("*", { count: "exact", head: true }).eq("status", "Pending"),
        ]);
      return { totalStudents, totalSkills, totalExchanges, activeExchanges, pendingRequests };
    },

    async listStudents() {
      return Store.profiles.listAll(null);
    },

    async listExchanges() {
      if (IS_DEMO_MODE) {
        const db = getDemoDb();
        return db.exchanges.map((e) => ({
          ...e,
          s1: db.profiles.find((p) => p.id === e.student1_id),
          s2: db.profiles.find((p) => p.id === e.student2_id),
        }));
      }
      const { data, error } = await supabaseClient
        .from("exchanges").select("*, s1:profiles!exchanges_student1_id_fkey(*), s2:profiles!exchanges_student2_id_fkey(*)");
      if (error) throw error;
      return data;
    },
  },
};
