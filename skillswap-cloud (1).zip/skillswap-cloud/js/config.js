/* =========================================================
   SkillSwap Cloud — Supabase Configuration
   -----------------------------------------------------------
   1. Create a free project at https://supabase.com
   2. Run database/schema.sql in the Supabase SQL editor
   3. Copy your Project URL and anon/public API key from
      Project Settings -> API and paste them below.
   4. NEVER put your service_role (secret) key here — only
      the public "anon" key belongs in frontend code.
========================================================= */

const SUPABASE_CONFIG = {
  url: "https://YOUR-PROJECT-REF.supabase.co",
  anonKey: "YOUR-SUPABASE-ANON-PUBLIC-KEY",
};

/* The app automatically runs in DEMO MODE (using the browser's
   localStorage as a stand-in database) until you replace the
   placeholders above with real Supabase credentials. This lets
   the whole project — register, login, skills, matching,
   requests, exchanges, messages, notifications, admin — be
   demoed instantly with zero setup, while still shipping the
   real Supabase code path for production use. */
const IS_DEMO_MODE =
  SUPABASE_CONFIG.url.includes("YOUR-PROJECT-REF") ||
  SUPABASE_CONFIG.anonKey.includes("YOUR-SUPABASE-ANON-PUBLIC-KEY");
